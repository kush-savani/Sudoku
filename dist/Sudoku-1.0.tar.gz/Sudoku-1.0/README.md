# Sudoku

A Python package to create a pair of solve and unsolve sudoku.

## Usage

import Sudoku 

puzzle,solution = create('easy')

display(puzzle) 