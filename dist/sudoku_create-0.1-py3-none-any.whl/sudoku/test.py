from sudoku import create,display
pu,sol = create('hard')
display(pu)
print()
display(sol)
